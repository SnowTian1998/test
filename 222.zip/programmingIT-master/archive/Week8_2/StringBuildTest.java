
public class StringBuildTest {
	public static void main(String[] args) {
	StringBuilder s = new StringBuilder("hello");
	s.append(" goodbye");
	System.out.println(s);
	}
}
