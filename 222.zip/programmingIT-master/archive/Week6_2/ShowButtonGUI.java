/**
 * creates and shows a GUI
 */
public class ShowButtonGUI
{
	public static void main(String [] args)
	{
		ButtonGUI myGUI = new ButtonGUI();
		myGUI.setVisible(true);
	}
}
