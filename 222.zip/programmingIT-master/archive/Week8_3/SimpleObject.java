
public class SimpleObject {
	private int a;
	public void setA(int newA) {
		this.a = newA;
	}
	public int getA() {
		return this.a;
	}
}
