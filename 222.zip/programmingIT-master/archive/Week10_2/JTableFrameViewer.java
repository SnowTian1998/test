import javax.swing.*;

/**
   This program shows a frame with a text area that displays
   the growth of an investment. 
*/
public class JTableFrameViewer
{  
   public static void main(String[] args)
   {  
      JTableFrame frame = new JTableFrame();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
   }
}
