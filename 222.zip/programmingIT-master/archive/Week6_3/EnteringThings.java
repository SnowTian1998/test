import java.util.Scanner;
public class EnteringThings {
	public static void main(String[] args) {
	System.out.println("Enter your age");
	Scanner s = new Scanner(System.in);
	int age = s.nextInt();
	System.out.println("Your age is: " +age);
	}
}
