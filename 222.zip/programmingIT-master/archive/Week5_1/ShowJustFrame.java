/**
 A simple class to show a single frame
*/

public class ShowJustFrame
{  
	public static void main(String [] args)
	{
		JustFrame frame = new JustFrame();
		frame.setVisible(true);
	}
}
