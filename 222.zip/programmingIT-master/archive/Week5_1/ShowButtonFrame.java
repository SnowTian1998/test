/**
 A simple class to show a single frame
*/

public class ShowButtonFrame
{  
	public static void main(String [] args)
	{
		ButtonFrame frame = new ButtonFrame();
		frame.setVisible(true);
	}
}
