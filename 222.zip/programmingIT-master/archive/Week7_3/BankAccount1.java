
public class BankAccount1 {
	public int pnds;
	public int pnce;
	public BankAccount1(int pn,int pe) {
		pnds = pn;
		pnce = pe;
	}
}
