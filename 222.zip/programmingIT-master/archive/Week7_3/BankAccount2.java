
public class BankAccount2 {
	private int pnds;
	private int pnce;
	public BankAccount2(int pn,int pe) {
		pnds = pn;
		pnce = pe;
	}
	public int getPnds() {
		return pnds;
	}
}
