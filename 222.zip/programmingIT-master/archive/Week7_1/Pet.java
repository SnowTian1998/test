
public class Pet {
	private String name;
	public Pet(String s) {
		name = s;
	}
	public String getName() {
		return name;
	}
}
