/**
 * Creates and shows a simple GUI
 */
public class ShowSimpleGUI
{
	public static void main(String [] args)
	{
		SimpleGUI myGUI = new SimpleGUI();
		myGUI.setVisible(true);
	}
}
