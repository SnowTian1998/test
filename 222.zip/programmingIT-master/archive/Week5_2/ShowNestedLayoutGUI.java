/**
 * creates and shows a GUI with nested layout
 */
public class ShowNestedLayoutGUI
{
	public static void main(String [] args)
	{
		NestedLayoutGUI myGUI = new NestedLayoutGUI();
		myGUI.setVisible(true);
	}
}
