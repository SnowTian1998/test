public class NandXObject {
    public static void main(String[] args) {
        NXBoard b = new NXBoard();
        // b.resetBoard();
        // System.out.println(b);
        // b.setChar(0, 0, 'x');
        // System.out.println(b);
        // b.playMove('o');
        // System.out.println(b);
        b.playGame();
    }
}