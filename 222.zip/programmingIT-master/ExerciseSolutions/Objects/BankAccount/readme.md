## Bank account lab solutions

- I changed the name to `BankAccountPerson` when it uses a Person object instead of a String to make things clear.
- It is the `BankAccountPerson` class that I extend for `SavingsAccount`
- My `Person` class is very simple - yours might be more complex.