
public class InsufficientFundsException extends RuntimeException {

}
