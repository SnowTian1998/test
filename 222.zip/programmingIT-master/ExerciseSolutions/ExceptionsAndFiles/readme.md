# File and exception solutions

- LabEx1 and LabEx2 are the place to start for Exceptions and Files.
- The other files give some extra solutions -- but LabEx1 and LabEx2 are the most comprehensive. Note that you will need to change file paths!
- A note from Alice:

>I’ve put the different parts of exercise 2 into different methods to separate them out. There are also two versions of the reverse method, one using the FileReader read method as suggested in the exercise, and one without